#!/usr/bin/env python
# coding: utf-8

# In[12]:


import pandas as pd
import statistics as st
import numpy as np
import matplotlib.pyplot as mt
import scipy as sp
from scipy.stats import probplot
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
df = pd.read_csv('/Users/abdelrahmannabil/Downloads/Project Requirements/Diabetes Dataset.csv')


# In[19]:


####### MEAN #########


# In[33]:


st.mean(df['Pregnancies']) #1


# In[12]:


st.mean(df['Glucose'])#2


# In[13]:


st.mean(df['BloodPressure'])#3


# In[14]:


st.mean(df['SkinThickness'])#4


# In[15]:


st.mean(df['Insulin'])#5


# In[16]:


st.mean(df['BMI'])#6


# In[17]:


st.mean(df['DiabetesPedigreeFunction'])#7


# In[18]:


st.mean(df['Age'])#8


# In[19]:


st.mean(df['Outcome'])#9


# In[ ]:


####### MEDIAN #########


# In[20]:


st.median(df['Pregnancies']) #1


# In[22]:


st.median(df['Glucose'])#2


# In[23]:


st.median(df['BloodPressure'])#3


# In[24]:


st.median(df['SkinThickness'])#4


# In[25]:


st.median(df['Insulin'])#5


# In[26]:


st.median(df['BMI'])#6


# In[27]:


st.median(df['DiabetesPedigreeFunction'])#7


# In[28]:


st.median(df['Age'])#8


# In[29]:


st.median(df['Outcome'])#9


# In[ ]:


####### MODE ########


# In[32]:


st.mode(df['Pregnancies'])#1


# In[33]:


st.mode(df['Glucose'])#2


# In[34]:


st.mode(df['BloodPressure'])#3


# In[35]:


st.mode(df['SkinThickness'])#4


# In[36]:


st.mode(df['Insulin'])#5


# In[37]:


st.mode(df['BMI'])#6


# In[38]:


st.mode(df['DiabetesPedigreeFunction'])#7


# In[39]:


st.mode(df['Age'])#8


# In[40]:


st.mode(df['Outcome'])#9


# In[ ]:


####### SD #########


# In[41]:


st.stdev(df['Pregnancies'])#1


# In[42]:


st.stdev(df['Glucose'])#2


# In[44]:


st.stdev(df['BloodPressure'])#3


# In[45]:


st.stdev(df['SkinThickness'])#4


# In[46]:


st.stdev(df['Insulin'])#5


# In[47]:


st.stdev(df['BMI'])#6


# In[48]:


st.stdev(df['DiabetesPedigreeFunction'])#7


# In[49]:


st.stdev(df['Age'])#8


# In[50]:


st.stdev(df['Outcome'])#9


# In[ ]:


####### Variance ##########


# In[51]:


st.variance(df['Pregnancies'])#1


# In[52]:


st.variance(df['Glucose'])#2


# In[53]:


st.variance(df['BloodPressure'])#3


# In[54]:


st.variance(df['SkinThickness'])#4


# In[55]:


st.variance(df['Insulin'])#5


# In[56]:


st.variance(df['BMI'])#6


# In[57]:


st.variance(df['DiabetesPedigreeFunction'])#7


# In[58]:


st.variance(df['Age'])#8


# In[59]:


st.variance(df['Outcome'])#9


# In[ ]:


########### QUARTILE ##########


# In[71]:


np.quantile(df['Pregnancies'],0.25)#1


# In[70]:


np.quantile(df['Pregnancies'],0.5)#1.2


# In[72]:


np.quantile(df['Pregnancies'],0.75)#1.3


# In[89]:


np.quantile(df['Pregnancies'],1)#1.4


# In[73]:


np.quantile(df['Glucose'],0.25)#2


# In[74]:


np.quantile(df['Glucose'],0.5)#2.2


# In[75]:


np.quantile(df['Glucose'],0.75)#2.3


# In[88]:


np.quantile(df['Glucose'],1)#2.4


# In[76]:


np.quantile(df['BloodPressure'],0.25)#3


# In[77]:


np.quantile(df['BloodPressure'],0.5)#3.2


# In[78]:


np.quantile(df['BloodPressure'],0.75)#3.3


# In[87]:


np.quantile(df['BloodPressure'],1)#3.4


# In[79]:


np.quantile(df['SkinThickness'],0.25)#4


# In[80]:


np.quantile(df['SkinThickness'],0.5)#4.2


# In[81]:


np.quantile(df['SkinThickness'],0.75)#4.3


# In[86]:


np.quantile(df['SkinThickness'],1)#4.4


# In[82]:


np.quantile(df['Insulin'],0.25)#5


# In[83]:


np.quantile(df['Insulin'],0.5)#5.2


# In[84]:


np.quantile(df['Insulin'],0.75)#5.3


# In[85]:


np.quantile(df['Insulin'],1)#5.4


# In[90]:


np.quantile(df['BMI'],0.25)#6


# In[91]:


np.quantile(df['BMI'],0.5)#6.2


# In[92]:


np.quantile(df['BMI'],0.75)#6.3


# In[93]:


np.quantile(df['BMI'],1)#6.4


# In[94]:


np.quantile(df['DiabetesPedigreeFunction'],0.25)#7


# In[95]:


np.quantile(df['DiabetesPedigreeFunction'],0.5)#7.2


# In[96]:


np.quantile(df['DiabetesPedigreeFunction'],0.75)#7.3


# In[97]:


np.quantile(df['DiabetesPedigreeFunction'],1)#7.4


# In[98]:


np.quantile(df['Age'],0.25)#8


# In[99]:


np.quantile(df['Age'],0.5)#8.2


# In[100]:


np.quantile(df['Age'],0.75)#8.3


# In[101]:


np.quantile(df['Age'],1)#8.4


# In[102]:


np.quantile(df['Outcome'],0.25)#9


# In[103]:


np.quantile(df['Outcome'],0.5)#9.2


# In[104]:


np.quantile(df['Outcome'],0.75)#9.3


# In[105]:


np.quantile(df['Outcome'],1)#9.4


# In[ ]:


####### MAX MIN ########


# In[11]:


p=df['Pregnancies'].max()
print (p)#1


# In[12]:


p=df['Pregnancies'].min()
print (p)#1.1


# In[13]:


p=df['Glucose'].max()
print (p)#2


# In[14]:


p=df['Glucose'].min()
print (p)#2.2


# In[15]:


p=df['BloodPressure'].max()
print (p)#3


# In[16]:


p=df['BloodPressure'].min()
print (p)#3.2


# In[19]:


p=df['SkinThickness'].max()
print (p)#4


# In[20]:


p=df['SkinThickness'].min()
print (p)#4.2


# In[17]:


p=df['Insulin'].max()
print (p)#5


# In[18]:


p=df['Insulin'].min()
print (p)#5.2


# In[21]:


p=df['BMI'].max()
print (p)#6


# In[22]:


p=df['BMI'].min()
print (p)#6.2


# In[23]:


p=df['DiabetesPedigreeFunction'].max()
print (p)#7


# In[24]:


p=df['DiabetesPedigreeFunction'].min()
print (p)#7.2


# In[25]:


p=df['Age'].max()
print (p)#8


# In[26]:


p=df['Age'].min()
print (p)#8.2


# In[27]:


p=df['Outcome'].max()
print (p)#9


# In[28]:


p=df['Outcome'].min()
print (p)#9.2


# In[ ]:


########## Individual Feature Analysis: ###########


# In[ ]:


########### Distribution Plots #############


# In[39]:


mt.hist(df['Pregnancies'],color='lightgreen', ec='black', bins=15)


# In[47]:


mt.hist(df['Glucose'],color='lightgreen', ec='black', bins=15)


# In[48]:


mt.hist(df['BloodPressure'],color='lightgreen', ec='black', bins=15)


# In[49]:


mt.hist(df['SkinThickness'],color='lightgreen', ec='black', bins=15)


# In[50]:


mt.hist(df['Insulin'],color='lightgreen', ec='black', bins=15)


# In[51]:


mt.hist(df['BMI'],color='lightgreen', ec='black', bins=15)


# In[52]:


mt.hist(df['DiabetesPedigreeFunction'],color='lightgreen', ec='black', bins=15)


# In[53]:


mt.hist(df['Age'],color='lightgreen', ec='black', bins=15)


# In[54]:


mt.hist(df['Outcome'],color='lightgreen', ec='black', bins=15)


# In[ ]:


##############  Bar Plots , pie chart #############3


# In[10]:


df['Pregnancies'].value_counts().plot(kind='bar')
mt.show()


# In[11]:


df['Pregnancies'].value_counts().plot(kind='pie')
mt.show()


# In[12]:


df['Glucose'].value_counts().plot(kind='bar')
mt.show()


# In[11]:


df['Glucose'].value_counts().plot(kind='pie')
mt.show()


# In[15]:


df['BloodPressure'].value_counts().plot(kind='bar')
mt.show()


# In[16]:


df['BloodPressure'].value_counts().plot(kind='pie')
mt.show()


# In[17]:


df['SkinThickness'].value_counts().plot(kind='bar')
mt.show()


# In[18]:


df['SkinThickness'].value_counts().plot(kind='pie')
mt.show()


# In[19]:


df['Insulin'].value_counts().plot(kind='bar')
mt.show()


# In[20]:


df['Insulin'].value_counts().plot(kind='pie')
mt.show()


# In[21]:


df['BMI'].value_counts().plot(kind='bar')
mt.show()


# In[22]:


df['BMI'].value_counts().plot(kind='pie')
mt.show()


# In[23]:


df['DiabetesPedigreeFunction'].value_counts().plot(kind='bar')
mt.show()


# In[24]:


df['DiabetesPedigreeFunction'].value_counts().plot(kind='pie')
mt.show()


# In[32]:


df['Age'].value_counts().plot(kind='bar')
mt.figure(figsize=(12, 12))
mt.show()


# In[33]:


df['Age'].value_counts().plot(kind='pie')
mt.figure(figsize=(10, 8))
mt.show()


# In[27]:


df['Outcome'].value_counts().plot(kind='bar')
mt.show()


# In[54]:


df['Outcome'].value_counts().plot(kind='pie')
mt.show()


# In[ ]:


########### Overall Feature Insights: #############


# In[16]:


corr = df.corr()
corr.style.background_gradient(cmap='coolwarm')


# In[18]:


# Correlation Matrix
rs = np.random.RandomState(0)
correlation_matrix = df.corr()
df = pd.DataFrame(rs.rand(10, 10))
mt.figure(figsize=(10, 8))
heatmap = mt.pcolor(correlation_matrix, cmap='coolwarm', vmin=-1, vmax=1)
mt.colorbar(heatmap)
for i in range(len(correlation_matrix)):
    for j in range(len(correlation_matrix)):
        mt.text(i + 0.5, j + 0.5, f"{correlation_matrix.iloc[i, j]:.2f}",
                 ha='center', va='center', color='black')
        mt.xticks(np.arange(0.5, len(correlation_matrix.columns), 1), correlation_matrix.columns, rotation=45)
mt.yticks(np.arange(0.5, len(correlation_matrix.index), 1), correlation_matrix.index)
mt.title('Correlation Matrix')

mt.show()


# In[ ]:


################### Feature-Pair Analysis ###################


# In[ ]:


################ ScatterPlots ###############


# In[7]:


mt.scatter(df['Glucose'],df['Insulin'])


# In[8]:


mt.scatter(df['Age'],df['Pregnancies'])


# In[ ]:


############# LinePlots #############


# In[9]:


mt.plot(df['Glucose'],df['Insulin'])


# In[10]:


mt.plot(df['BloodPressure'],df['Age'])


# In[ ]:


########### ADDITION PLOT #############


# In[11]:


mt.boxplot(df['Pregnancies'])


# In[12]:


mt.boxplot(df['Glucose'])


# In[13]:


mt.boxplot(df['BloodPressure'])


# In[14]:


mt.boxplot(df['SkinThickness'])


# In[15]:


mt.boxplot(df['Insulin'])


# In[16]:


mt.boxplot(df['BMI'])


# In[17]:


mt.boxplot(df['DiabetesPedigreeFunction'])


# In[18]:


mt.boxplot(df['Age'])


# In[19]:


mt.boxplot(df['Outcome'])


# In[24]:


a = np.random.random((10, 10))
mt.imshow(a, cmap='hot', interpolation='nearest')
mt.show()


# In[ ]:


#################### Probability Plot #################


# In[26]:


for column in df.columns:
    mt.figure(figsize=(10, 8))
    probplot(df[column], plot=mt)
    mt.title(f'Probability Plot of {column}')
    mt.xlabel('Theoretical Quantiles')
    mt.ylabel(f'Quantiles of {column}')
    mt.show()


# In[ ]:


###### Skewness of histogram ############3


# In[37]:


mt.figure(figsize=(8, 6))

# Plot the histogram
df['Pregnancies'].plot(kind='hist', color='lightgreen', edgecolor='black', bins=15, density=True)

# Add skewness curve using Pandas' plot.kde
df['Pregnancies'].plot(kind='kde', color='blue', linestyle='dashed', label='Skewness Curve')

mt.title('Histogram with Skewness Curve')
mt.xlabel('Pregnancies')
mt.ylabel('Frequency')
mt.legend()
mt.show()


# In[3]:


mt.figure(figsize=(8, 6))

# Plot the histogram
df['Glucose'].plot(kind='hist', color='lightgreen', edgecolor='black', bins=15, density=True)

# Add skewness curve using Pandas' plot.kde
df['Glucose'].plot(kind='kde', color='blue', linestyle='dashed', label='Skewness Curve')

mt.title('Histogram with Skewness Curve')
mt.xlabel('Glucose')
mt.ylabel('Frequency')
mt.legend()
mt.show()


# In[4]:


mt.figure(figsize=(8, 6))

# Plot the histogram
df['BloodPressure'].plot(kind='hist', color='lightgreen', edgecolor='black', bins=15, density=True)

# Add skewness curve using Pandas' plot.kde
df['BloodPressure'].plot(kind='kde', color='blue', linestyle='dashed', label='Skewness Curve')

mt.title('Histogram with Skewness Curve')
mt.xlabel('BloodPressure')
mt.ylabel('Frequency')
mt.legend()
mt.show()


# In[5]:


mt.figure(figsize=(8, 6))

# Plot the histogram
df['SkinThickness'].plot(kind='hist', color='lightgreen', edgecolor='black', bins=15, density=True)

# Add skewness curve using Pandas' plot.kde
df['SkinThickness'].plot(kind='kde', color='blue', linestyle='dashed', label='Skewness Curve')

mt.title('Histogram with Skewness Curve')
mt.xlabel('SkinThickness')
mt.ylabel('Frequency')
mt.legend()
mt.show()


# In[6]:


mt.figure(figsize=(8, 6))

# Plot the histogram
df['Insulin'].plot(kind='hist', color='lightgreen', edgecolor='black', bins=15, density=True)

# Add skewness curve using Pandas' plot.kde
df['Insulin'].plot(kind='kde', color='blue', linestyle='dashed', label='Skewness Curve')

mt.title('Histogram with Skewness Curve')
mt.xlabel('Insulin')
mt.ylabel('Frequency')
mt.legend()
mt.show()


# In[7]:


mt.figure(figsize=(8, 6))

# Plot the histogram
df['BMI'].plot(kind='hist', color='lightgreen', edgecolor='black', bins=15, density=True)

# Add skewness curve using Pandas' plot.kde
df['BMI'].plot(kind='kde', color='blue', linestyle='dashed', label='Skewness Curve')

mt.title('Histogram with Skewness Curve')
mt.xlabel('BMI')
mt.ylabel('Frequency')
mt.legend()
mt.show()


# In[9]:


mt.figure(figsize=(8, 6))

# Plot the histogram
df['DiabetesPedigreeFunction'].plot(kind='hist', color='lightgreen', edgecolor='black', bins=15, density=True)

# Add skewness curve using Pandas' plot.kde
df['DiabetesPedigreeFunction'].plot(kind='kde', color='blue', linestyle='dashed', label='Skewness Curve')

mt.title('Histogram with Skewness Curve')
mt.xlabel('DiabetesPedigreeFunction')
mt.ylabel('Frequency')
mt.legend()
mt.show()


# In[10]:


mt.figure(figsize=(8, 6))

# Plot the histogram
df['Age'].plot(kind='hist', color='lightgreen', edgecolor='black', bins=15, density=True)

# Add skewness curve using Pandas' plot.kde
df['Age'].plot(kind='kde', color='blue', linestyle='dashed', label='Skewness Curve')

mt.title('Histogram with Skewness Curve')
mt.xlabel('Age')
mt.ylabel('Frequency')
mt.legend()
mt.show()


# In[11]:


mt.figure(figsize=(8, 6))

# Plot the histogram
df['Outcome'].plot(kind='hist', color='lightgreen', edgecolor='black', bins=15, density=True)

# Add skewness curve using Pandas' plot.kde
df['Outcome'].plot(kind='kde', color='blue', linestyle='dashed', label='Skewness Curve')

mt.title('Histogram with Skewness Curve')
mt.xlabel('Outcome')
mt.ylabel('Frequency')
mt.legend()
mt.show()


# In[ ]:


################ Linear Regression ################


# In[13]:


X = df['Glucose'].values.reshape(-1, 1)
y = df['Insulin'].values
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
mt.scatter(X_test, y_test, color='black', label='Actual data')
mt.plot(X_test, y_pred, color='blue', linewidth=3, label='Linear regression line')
mt.title('Linear Regression')
mt.xlabel('X')
mt.ylabel('Y')
mt.legend()
mt.show()


# In[15]:


X = df['BloodPressure'].values.reshape(-1, 1)
y = df['Age'].values
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
mt.scatter(X_test, y_test, color='black', label='Actual data')
mt.plot(X_test, y_pred, color='blue', linewidth=3, label='Linear regression line')
mt.title('Linear Regression')
mt.xlabel('X')
mt.ylabel('Y')
mt.legend()
mt.show()


# In[16]:


X = df['BMI'].values.reshape(-1, 1)
y = df['SkinThickness'].values
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
mt.scatter(X_test, y_test, color='black', label='Actual data')
mt.plot(X_test, y_pred, color='blue', linewidth=3, label='Linear regression line')
mt.title('Linear Regression')
mt.xlabel('X')
mt.ylabel('Y')
mt.legend()
mt.show()


# In[ ]:




